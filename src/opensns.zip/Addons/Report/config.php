<?php

return array(
    'meta'=>array(//配置在表单中的键名 ,这个会是config[title]
        'title'=>'举报行为：',//表单的文字
        'type'=>'textarea',		 //表单的类型：text、textarea、checkbox、radio、select等
        'height'=>'500px',
        'value'=>'',			 //表单的默认值
        'tip'=>'管理员设置非法行为，一行一个'
    ),




);